import { useParams } from "react-router-dom";

function CategoryProducts() {
  const { categoryName } = useParams();

  return (
    <div className="min-h-screen bg-gray-100">

      <div className="max-w-7xl mx-auto p-6">

        {/* Breadcrumb */}
        <p className="text-sm text-gray-500 mb-2">
          Home / Categories / {categoryName}
        </p>

        {/* Page Title */}
        <h1 className="text-3xl font-bold mb-6">
          {categoryName}
        </h1>

        {/* Products will come here */}
        <div className="bg-white rounded-2xl shadow p-10 text-center text-gray-500">
          Products of "{categoryName}" will appear here.
        </div>

      </div>

    </div>
  );
}

export default CategoryProducts;