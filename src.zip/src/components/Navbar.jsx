import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";

import { auth } from "../services/firebase";
import { logoutCustomer } from "../services/customerAuthService";
import { getCustomer } from "../services/customerService";

function Navbar({
  cartItems,
  setShowCart,
  logo,
}) {
  const navigate = useNavigate();

  const [customer, setCustomer] = useState(null);
  const [customerProfile, setCustomerProfile] = useState(null);
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCustomer(user);

      if (user) {
        const profile = await getCustomer(user.uid);
        setCustomerProfile(profile);
      } else {
        setCustomerProfile(null);
      }
    });

    return unsubscribe;
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-green-600 shadow-lg">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center gap-6">

        {/* Logo */}
        <div
          onClick={() => navigate("/")}
          className="flex items-center gap-3 cursor-pointer flex-shrink-0"
        >
          <img
            src={logo}
            alt="HomeEcart"
            className="w-12 h-12 rounded-xl bg-white p-1"
          />

          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              HomeEcart
            </h1>

            <p className="text-xs text-green-100">
              📍 Dehri-On-Sone
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="flex-1 hidden md:block">
          <input
            type="text"
            placeholder="🔍 Search groceries..."
            className="w-full px-5 py-3 rounded-full bg-white text-gray-700 shadow-md outline-none focus:ring-2 focus:ring-yellow-300"
          />
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-4 flex-shrink-0">

          {customer ? (
            <div className="relative">

              {/* Account Button */}
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 rounded-full px-3 py-2 transition"
              >
                <div className="w-9 h-9 rounded-full bg-white text-green-600 flex items-center justify-center font-bold">
                  {customerProfile?.name
                    ? customerProfile.name.charAt(0).toUpperCase()
                    : "👤"}
                </div>

                <div className="hidden lg:block text-left">
                  <p className="text-sm font-semibold text-white">
                    {customerProfile?.name || "Customer"}
                  </p>

                  <p className="text-[11px] text-green-100">
                    My Account
                  </p>
                </div>

                <span className="text-xs text-white">▼</span>
              </button>

              {/* Dropdown */}
              {showMenu && (
                <div className="absolute right-0 top-14 w-72 bg-white rounded-2xl shadow-2xl overflow-hidden z-50">

                  <div className="bg-green-600 p-5 text-white">

                    <div className="flex items-center gap-4">

                      <div className="w-14 h-14 rounded-full bg-white text-green-600 flex items-center justify-center text-2xl font-bold">
                        {customerProfile?.name
                          ? customerProfile.name.charAt(0).toUpperCase()
                          : "👤"}
                      </div>

                      <div>
                        <h3 className="font-bold text-lg">
                          {customerProfile?.name || "Customer"}
                        </h3>

                        <p className="text-sm text-green-100">
                          {customerProfile?.phone}
                        </p>
                      </div>

                    </div>

                  </div>

                  <button className="w-full text-left px-5 py-4 hover:bg-gray-100 transition">
                    👤 My Profile
                  </button>

                  <button className="w-full text-left px-5 py-4 hover:bg-gray-100 transition">
                    📦 My Orders
                  </button>

                  <hr />

                  <button
                    onClick={async () => {
                      await logoutCustomer();
                      setShowMenu(false);
                      navigate("/");
                    }}
                    className="w-full text-left px-5 py-4 text-red-600 hover:bg-red-50 transition"
                  >
                    🚪 Logout
                  </button>

                </div>
              )}

            </div>
          ) : (
            <button
              onClick={() => navigate("/login")}
              className="bg-white text-green-700 px-5 py-2.5 rounded-full font-semibold hover:bg-gray-100 transition"
            >
              Login
            </button>
          )}

          {/* Cart */}
          <button
            onClick={() => setShowCart(true)}
            className="relative bg-yellow-400 hover:bg-yellow-300 text-black px-5 py-3 rounded-full font-semibold shadow transition"
          >
            🛒 Cart

            <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-600 text-white text-xs flex items-center justify-center">
              {cartItems.length}
            </span>
          </button>

        </div>

      </div>
    </header>
  );
}

export default Navbar;